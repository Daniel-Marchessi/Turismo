(function($, undefined){
	$('.ait-sc-rule-btn-top').on('click', function(){
		$('html, body').animate({
			scrollTop: 0
		}, 1000);
	});
})(jQuery);
