This is basic skeleton for your child theme. Here you can copy templates files from your parent theme. 

Documentation for child theme can be found here: http://www.ait-themes.club/doc/child-theme/